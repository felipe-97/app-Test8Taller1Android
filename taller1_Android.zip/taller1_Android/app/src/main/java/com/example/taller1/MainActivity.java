package com.example.taller1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
Context ctx;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d( "CVA","onCreate");
        ctx =this;

       setContentView(R.layout.activity_main);



       Button fab =findViewById(R.id.mi_boton);
       fab.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent i = new Intent(ctx, MenuPrincipal.class);


               startActivity(i);

           }

       });

       Button fab1 = findViewById(R.id.mi_boton1);
       fab1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent d =new Intent(ctx,signup.class);
               startActivity(d);
           }
       });












    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d( "CVA","onStart");

    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.d( "CVA","onResume");
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.d( "CVA","onPause");

    }



    @Override
    protected void onStop() {
        super.onStop();
        Log.d( "CVA","onStop");

    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d( "CVA","onRestart");

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d( "CVA","onDestroy");

    }
}
